# Assets

Place future website assets here.

Recommended filenames:

- `allan-industrial-site.jpeg` - hero field photo
- `allan-profile.jpeg` - professional profile/headshot photo
- `allan-hydro-field.jpeg` - supporting field photo
- `allan-industrial-selfie.jpeg` - supporting field photo
- `capability-statement.pdf` - downloadable capability statement
- `resume.pdf` - optional resume PDF, if you choose to provide a direct download

After adding files, update the paths in `site-data.js`.
